import streamlit as st
import pdfplumber
import plotly.graph_objects as go
import pandas as pd
import requests
import re
from bs4 import BeautifulSoup

st.set_page_config(page_title="MediGenie AI", layout="wide")

# ---------------------------------------------------
# PDF EXTRACTION
# ---------------------------------------------------

def extract_pdf_text(uploaded_file):

    text = ""

    with pdfplumber.open(uploaded_file) as pdf:

        for page in pdf.pages:

            page_text = page.extract_text()

            if page_text:
                text += page_text + "\n"

    return text


# ---------------------------------------------------
# METRIC EXTRACTION
# ---------------------------------------------------

def extract_metric(text, metric):

    pattern = rf"{metric}\s*[:\-]?\s*(\d+\.?\d*)"

    match = re.search(pattern, text, re.IGNORECASE)

    if match:
        return float(match.group(1))

    return None


# ---------------------------------------------------
# ANALYSIS
# ---------------------------------------------------

def analyze_report(text):

    return {

        "HbA1c": extract_metric(text, "HbA1c"),
        "LDL": extract_metric(text, "LDL"),
        "VitaminD": extract_metric(text, "VitaminD")
    }


# ---------------------------------------------------
# RISKS
# ---------------------------------------------------

def assess_risk(metrics):

    risks = []

    if metrics["HbA1c"] and metrics["HbA1c"] > 6.5:
        risks.append("Diabetes Risk")

    if metrics["LDL"] and metrics["LDL"] > 160:
        risks.append("Cardiac Risk")

    if metrics["VitaminD"] and metrics["VitaminD"] < 20:
        risks.append("Vitamin D Deficiency")

    return risks


# ---------------------------------------------------
# SPECIALISTS
# ---------------------------------------------------

def recommend_specialists(metrics):

    specialists = []

    if metrics["LDL"] and metrics["LDL"] > 160:
        specialists.append("Cardiologist")

    if metrics["HbA1c"] and metrics["HbA1c"] > 6.5:
        specialists.append("Endocrinologist")

    if metrics["VitaminD"] and metrics["VitaminD"] < 20:
        specialists.append("General Physician")

    return list(set(specialists))


# ---------------------------------------------------
# LIVE SEARCH
# ---------------------------------------------------

def search_live_doctors(specialist, city):

    doctors = []

    try:

        query = f"{specialist} {city}"

        url = "https://html.duckduckgo.com/html/"

        response = requests.get(
            url,
            params={"q": query},
            headers={
                "User-Agent":
                "Mozilla/5.0"
            },
            timeout=10
        )

        soup = BeautifulSoup(
            response.text,
            "html.parser"
        )

        results = soup.select(".result")

        for result in results[:5]:

            title = result.select_one(".result__title")

            snippet = result.select_one(".result__snippet")

            doctors.append({

                "name":
                title.get_text(strip=True)
                if title else "Unknown",

                "details":
                snippet.get_text(strip=True)
                if snippet else "No details available"
            })

    except Exception:

        doctors = []

    return doctors


# ---------------------------------------------------
# FALLBACK DATA
# ---------------------------------------------------

def fallback_doctors(specialist):

    data = {

        "Cardiologist": [

            {
                "name": "Dr Amit Sharma",
                "details":
                "Kharadi Pune | Rating 4.8 | Today 5 PM"
            },

            {
                "name": "Dr Neha Kulkarni",
                "details":
                "Baner Pune | Rating 4.9 | Tomorrow 10 AM"
            }
        ],

        "Endocrinologist": [

            {
                "name": "Dr Priya Mehta",
                "details":
                "Viman Nagar Pune | Rating 4.8"
            },

            {
                "name": "Dr Sameer Joshi",
                "details":
                "Wakad Pune | Rating 4.7"
            }
        ],

        "General Physician": [

            {
                "name": "Dr Rajesh Patil",
                "details":
                "Hadapsar Pune | Rating 4.6"
            },

            {
                "name": "Dr Manish Deshmukh",
                "details":
                "Kothrud Pune | Rating 4.8"
            }
        ]
    }

    return data.get(specialist, [])


# ---------------------------------------------------
# HEALTH SCORE
# ---------------------------------------------------

def calculate_score(metrics):

    score = 100

    if metrics["HbA1c"] and metrics["HbA1c"] > 6.5:
        score -= 15

    if metrics["LDL"] and metrics["LDL"] > 160:
        score -= 15

    if metrics["VitaminD"] and metrics["VitaminD"] < 20:
        score -= 10

    return score


# ---------------------------------------------------
# LIFESTYLE
# ---------------------------------------------------

def recommendations(metrics):

    recs = []

    if metrics["HbA1c"] and metrics["HbA1c"] > 6.5:
        recs.append(
            "Reduce sugar intake and walk daily."
        )

    if metrics["LDL"] and metrics["LDL"] > 160:
        recs.append(
            "Reduce oily food and increase cardio."
        )

    if metrics["VitaminD"] and metrics["VitaminD"] < 20:
        recs.append(
            "Increase sunlight exposure."
        )

    return recs


# ---------------------------------------------------
# UI
# ---------------------------------------------------

st.title("🏥 MediGenie AI")

st.subheader(
    "Healthcare Report Analyzer & Doctor Recommendation Agent"
)

city = st.sidebar.text_input(
    "Location",
    value="Pune"
)

uploaded_file = st.file_uploader(
    "Upload Medical Report",
    type=["pdf"]
)

if uploaded_file:

    text = extract_pdf_text(uploaded_file)

    metrics = analyze_report(text)

    st.success("✅ Report Analyzed")

    st.json(metrics)

    risks = assess_risk(metrics)

    st.subheader("Risk Assessment")

    for risk in risks:
        st.warning(risk)

    specialists = recommend_specialists(metrics)

    st.subheader(
        "Specialist Recommendations"
    )

    for specialist in specialists:
        st.info(specialist)

    st.subheader(
        "🔎 Live Doctor Discovery"
    )

    for specialist in specialists:

        st.write(
            f"Searching for {specialist}..."
        )

        doctors = search_live_doctors(
            specialist,
            city
        )

        if len(doctors) == 0:

            st.warning(
                "Live source unavailable. Using curated provider network."
            )

            doctors = fallback_doctors(
                specialist
            )

        for doctor in doctors:

            st.success(
                f"""
Doctor: {doctor['name']}

Details:
{doctor['details']}
"""
            )

            if st.button(
                f"Book Appointment - {doctor['name']}"
            ):

                st.balloons()

                st.success(
                    f"""
✅ Appointment Request Submitted

Provider:
{doctor['name']}
"""
                )

    st.subheader(
        "Lifestyle Recommendations"
    )

    for recommendation in recommendations(metrics):

        st.write("✅", recommendation)

    score = calculate_score(metrics)

    fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=score,
            title={
                "text": "Health Score"
            },
            gauge={
                "axis": {
                    "range": [0, 100]
                }
            }
        )
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )